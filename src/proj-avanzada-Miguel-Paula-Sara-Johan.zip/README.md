# Integrantes

- Miguel Francisco Vargas Contreras
- Sara Rodriguez Urueña
- Maria Paula Sanabria Cristancho
- Johan Steven Guerra Hueso